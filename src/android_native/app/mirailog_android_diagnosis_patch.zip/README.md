# ミライログ Android 診断結果カード修正（差分ファイル）

## 適用方法
このZIP内の `src/android_native/` 以下を既存プロジェクトの同じパスに上書きしてください。
Android Studioで開くのは `src/android_native/` のプロジェクトです。

## 16枚の画像の追加（必須）
手元の透過PNG（実ファイル）を、既存の大文字ファイル名のまま以下にコピーしてください。

`src/android_native/app/src/main/assets/diagnosis_illustrations/`

ファイル: GIPS.png, GIPD.png, GIFS.png, GIFD.png, GXPS.png, GXPD.png, GXFS.png, GXFD.png, EIPS.png, EIPD.png, EIFS.png, EIFD.png, EXPS.png, EXPD.png, EXFS.png, EXFD.png

PNGが置かれていない場合は、カードの文章のみ表示されます（クラッシュしません）。
今回の添付はデザイン参考画像のみであり、16枚の実PNGはこの修正ZIPには含まれていません。

## 修正点
- `DiagnosisResultContent.kt`: カードをヘッダー/タイプ名/タイプコード/説明文/注記/右側イラスト構成に変更。
  `result.typeName`, `result.typeCode`, `result.description` を使用。`typeCode` で画像を選択。
  比較対象は直前1件のみ。
- `DiagnosisRepositories.kt`: 履歴取得を `limit=3` から `limit=2` に変更。
- `DiagnosisSummaryViewModel.kt`: 比較対象を直前1件に変更。
- `DiagnosisViewModel.kt`: 比較対象を直前1件に変更。

## 未修正・要確認
- Djangoの `/diagnoses/latest` がプロフィール内の古い latestDiagnosis を優先する可能性。
  これはAndroid側の表示修正だけでは根本解決しません。
- Android APKのビルド・エミュレーター動作確認は、この環境では実施していません。
